% File with the mechanical connectivities for design_01 and design_02 and their C3 complexities

% combined design_01 mechanical connectivity matrix
% combined column lables:
% D2S1	D2S2	D2S3	D2S4	D2S5	D2S6	D2S7    D1S3
% D1S1  D1S2            D1S4
design_01_cb=[  0	1	0	0	0	0	0	0;
                1	0	0	0	0	0	0	1;
                0	0	0	0	0	0	0	0;
                0	0	0	0	0	0	0	1;
                0	0	0	0	0	0	0	0;
                0	0	0	0	0	0	0	0;
                0	0	0	0	0	0	0	0;
                0	1	0	1	0	0	0	0;
             ];
%
% combined design_02 mechanical connectivity matrix
% combined column lables:
% D2S1	D2S2	D2S3	D2S4	D2S5	D2S6	D2S7    D1S3
% D1S1  D1S2            D1S4
design_02_cb=[  0	0	0	0	0	1	0	0;
                0	0	0	0	0	1	0	0;
                0	0	0	0	0	0	1	0;
                0	0	0	0	0	1	0	0;
                0	0	0	0	0	0	1	0;
                1	1	0	1	0	0	1	0;
                0	0	1	0	1	1	0	0;
                0	0	0	0	0	0	0	0;
             ];

% calculating topological complexity values
n_design_01_cb_full=size(design_01_cb);
n_design_01_cb=n_design_01_cb_full(1,1);

n_design_02_cb_full=size(design_02_cb);
n_design_02_cb=n_design_02_cb_full(1,1);

C3_design_01_cb=1/n_design_01_cb*sum(svd(design_01_cb));
C3_design_02_cb=1/n_design_02_cb*sum(svd(design_02_cb));

%print the C3 values for design-01 and design-02
clc;
fprintf('C3 for design-01 = %3.2f\n',C3_design_01_cb);
fprintf('C3 for design-02 = %3.2f\n',C3_design_02_cb);
